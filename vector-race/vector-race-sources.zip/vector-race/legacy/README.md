# Prototype Tkinter historique

Cette version est conservée pour documenter la base du jeu. Elle nécessite Python, Tkinter et NumPy (`pip install -r requirements.txt`). Depuis ce dossier : `python vector-race.py -t full_track.trk` ; ajouter `-e` pour l’éditeur historique.

Corrections appliquées : tableaux de joueurs indépendants, contrôle continu des collisions, arrêt obligatoire sur l’arrivée, import du fichier fourni avec ses booléens Python, appel de méthode de l’éditeur, rafraîchissement après pose, bornes des dimensions.

Pour l’interface complète, les circuits, les records, l’atelier et la reprise de partie, utiliser `../vector-race.py`, le lanceur du jeu principal. Le prototype garde son interface et son comportement de fermeture de fin de partie historiques.
