"""Continuous segment/road-union collision, matching the browser engine."""
import math

BORDER = 1 / 3
EPS = 1e-8


def bounds(block):
    if block["block_style"] == "StraightRoadBlock":
        return (block["left"] - BORDER, block["bottom"] - BORDER,
                block["right"] + BORDER, block["top"] + BORDER)
    if block["block_style"] == "StartFinishBlock":
        x, y = block["start_pos"]
        return (x - BORDER, y - BORDER,
                x + (block["width"] - 1 if block["is_vertical"] else 0) + BORDER,
                y + (0 if block["is_vertical"] else block["width"] - 1) + BORDER)
    x, y = block["center"]
    rx, ry = (r + BORDER for r in block["outside_rad"])
    a = block["angle"]
    return (x - (rx if a in (90, 180) else 0), y - (ry if a >= 180 else 0),
            x + (rx if a in (0, 270) else 0), y + (ry if a < 180 else 0))


def contains(block, point):
    x, y = point
    l, b, r, t = bounds(block)
    if x < l - EPS or x > r + EPS or y < b - EPS or y > t + EPS:
        return False
    if block["block_style"] != "EllipsisTurnBlock":
        return True
    dx, dy = x - block["center"][0], y - block["center"][1]
    ix, iy = (r - BORDER for r in block["inside_rad"])
    ox, oy = (r + BORDER for r in block["outside_rad"])
    return dx * dx / ox ** 2 + dy * dy / oy ** 2 <= 1 + EPS and dx * dx / ix ** 2 + dy * dy / iy ** 2 >= 1 - EPS


def segment_allowed(blocks, start, end):
    if not any(contains(b, start) for b in blocks) or not any(contains(b, end) for b in blocks):
        return False
    delta = (end[0] - start[0], end[1] - start[1])
    if delta == (0, 0):
        return True
    values = [0.0, 1.0]
    for block in blocks:
        l, b, r, t = bounds(block)
        for axis, edge in ((0, l), (0, r), (1, b), (1, t)):
            if delta[axis]:
                q = (edge - start[axis]) / delta[axis]
                if 0 < q < 1:
                    values.append(q)
        if block["block_style"] == "EllipsisTurnBlock":
            for rad, offset in ((block["inside_rad"], -BORDER), (block["outside_rad"], BORDER)):
                rx, ry = (v + offset for v in rad)
                x, y = (start[0] - block["center"][0]) / rx, (start[1] - block["center"][1]) / ry
                dx, dy = delta[0] / rx, delta[1] / ry
                a, b, c = dx * dx + dy * dy, 2 * (x * dx + y * dy), x * x + y * y - 1
                disc = b * b - 4 * a * c
                if a and disc >= 0:
                    for q in ((-b - math.sqrt(disc)) / (2 * a), (-b + math.sqrt(disc)) / (2 * a)):
                        if 0 < q < 1:
                            values.append(q)
    values.sort()
    for a, b in zip(values, values[1:]):
        if b - a <= EPS:
            continue
        t = (a + b) / 2
        p = (start[0] + t * delta[0], start[1] + t * delta[1])
        if not any(contains(block, p) for block in blocks):
            return False
    return True
