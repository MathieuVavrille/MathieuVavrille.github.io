#!/usr/bin/env python3
"""Launch Vector Race locally with Python's standard library (3.9+)."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import threading
import webbrowser


def main():
    parser = argparse.ArgumentParser(description="Vector Race — course tactique et atelier de circuits")
    parser.add_argument("-e", "--editor", action="store_true", help="Ouvrir l’atelier")
    parser.add_argument("-t", "--track", type=Path, help="Charger un fichier .trk")
    parser.add_argument("--port", type=int, default=0, help="Port local (0 = automatique)")
    parser.add_argument("--no-browser", action="store_true", help="Afficher l’URL sans ouvrir le navigateur")
    args = parser.parse_args()
    selected = None
    if args.track:
        try:
            if args.track.stat().st_size > 500000:
                parser.error("Fichier trop volumineux (500 Ko maximum)")
            selected = args.track.read_bytes()
        except OSError as exc:
            parser.error(str(exc))

    class Handler(SimpleHTTPRequestHandler):
        def do_GET(self):
            if self.path.split("?", 1)[0] == "/launch.trk":
                if selected is None:
                    self.send_error(404)
                else:
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Length", str(len(selected)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    self.wfile.write(selected)
                return
            super().do_GET()

        def log_message(self, *args):
            pass

    directory = Path(__file__).resolve().parent / "dist"
    with ThreadingHTTPServer(("127.0.0.1", args.port), partial(Handler, directory=str(directory))) as server:
        url = f"http://127.0.0.1:{server.server_port}/"
        if selected is not None:
            url += "?launch=1"
        if args.editor:
            url += "#atelier"
        print(f"Vector Race : {url}", flush=True)
        print("Garde cette fenêtre ouverte. Ctrl+C pour arrêter.", flush=True)
        if not args.no_browser:
            threading.Timer(0.4, lambda: webbrowser.open(url)).start()
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\nÀ la prochaine course !")


if __name__ == "__main__":
    main()
