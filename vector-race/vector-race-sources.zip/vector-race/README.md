# Vector Race

Un jeu de course tactique sur grille, au tour par tour. Interface en français, souris, tactile et clavier. Aucun compte, serveur de jeu ou service externe requis.

## Jouer en local

Python 3.9 ou plus récent suffit. Depuis le dossier du projet :

```bash
python vector-race.py
```

Le navigateur s’ouvre automatiquement. Garder le terminal ouvert ; Ctrl+C arrête le serveur local.

```bash
python vector-race.py --editor
python vector-race.py --track mon-circuit.trk
python vector-race.py --editor --track mon-circuit.trk
python vector-race.py --port 8080 --no-browser
```

Alternative : servir `dist/` avec n’importe quel serveur HTTP statique. L’ouverture directe de `index.html` en `file://` n’est pas prise en charge : les modules JavaScript et le solveur utilisent HTTP.

## Le principe conservé du prototype

1. Le véhicule commence sur un point choisi de la ligne de départ, avec une vitesse `(0, 0)`.
2. À chaque tour, on ajoute indépendamment `−1`, `0` ou `+1` aux composantes x et y de la vitesse : neuf accélérations possibles.
3. On avance selon **la nouvelle vitesse**. Sans accélération, on conserve son élan.
4. **Tout le segment** du déplacement doit rester sur la piste. Il est interdit de sauter au-dessus du vide, même si le point d’arrivée est valide.
5. Pour gagner, il faut atteindre un point de la ligne d’arrivée **avec une vitesse `(0, 0)`**. On peut avoir besoin d’un dernier tour de freinage sans déplacement.

Il n’y a pas de chrono : le score compte les coups. Pas de gravité, de braquage automobile continu ou de vitesse artificiellement plafonnée.

## Ce que contient cette version

- Six circuits accessibles librement, dont le tracé original entièrement conservé.
- Départ sans bouton fixe : choisir sa position sur la ligne verte, puis jouer sa première accélération. Le départ reste modifiable tant qu’aucun coup n’a été joué.
- Présentation du principe dans une fenêtre au chargement, accessible à nouveau via « ? ». Les onglets principaux sont Course et Atelier.
- Thèmes sombre et clair, y compris le canvas, avec sélecteur à côté du son. Préférence mémorisée sur l’appareil.
- Interface complète français/anglais avec bascule FR/EN et préférence mémorisée : menus, présentation, descriptions des circuits, messages, erreurs, solveur et libellés du canvas. La langue et le thème se changent sans réinitialiser la course ou modifier les noms des circuits personnels.
- Circuits personnalisés enregistrés accessibles dans Course, sous « Créer mon circuit », avec records, objectif optimal calculé en arrière-plan et reprise après rechargement. Un circuit incomplet renvoie à l’atelier pour être terminé.
- Objectifs or calculés par recherche exhaustive du plus court chemin : 8, 12, 16, 18, 26 et 40 coups. Ils prennent en compte tous les points de départ. Argent jusqu’à trois coups de plus ; bronze pour toute arrivée valide.
- Aperçu des neuf destinations et de leur trajectoire. Les destinations rouges provoquent une sortie de piste si on les choisit.
- Résultats, reprise du dernier coup, recommencement, pause, explication des règles, sons optionnels.
- Indice calculé depuis l’état actuel ; les calculs tournent dans un Web Worker.
- Solveur optimal sous « Un coup de pouce » : recherche en largeur depuis tous les points de départ, tracé complet et animation progressive jusqu’à l’arrêt final. Pause/reprise, relecture et vitesses ×0,5 à ×4. La course personnelle reste en pause et se retrouve avec « Revenir à ma course ». Une recherche annulée ou limitée ne présente aucune fausse solution optimale.
- Records, meilleur tracé fantôme, reprise de la course et circuits personnels sauvegardés dans le navigateur de l’appareil. Les données ne se synchronisent pas entre appareils ; exporter les `.trk` pour les transférer.
- Annuler, demander un indice ou consulter la solution passe la tentative en entraînement ; elle n’enregistre pas de record. La démonstration ne modifie pas les coups de la course ni les records.
- Atelier avec routes rectangulaires, quarts d’ellipse, départ/arrivée, rotation, gomme, annuler/rétablir, brouillon automatique, 30 emplacements, import/export `.trk` et validation d’une solution.
- Virages elliptiques à largeurs début A / fin B indépendantes. Les repères A et B suivent la rotation ; les rayons extérieurs correspondants restent compatibles avec le format `.trk` existant.
- Édition directe des blocs déjà posés ou importés : sélection, déplacement, redimensionnement par les bords/coins et poignées, rotation, suppression et dimensions liées au panneau. Les curseurs de redimensionnement apparaissent au survol des bords. Chaque glissement ou édition de champ est une seule étape d’annulation.
- Réinitialisation de la forme de base du bloc sélectionné, annulable : route de largeur 5 et longueur 12, virage de rayons intérieurs 4 et largeur 5, ligne de largeur 5. La position et l’orientation restent les mêmes. Pour la plume, les points sont conservés, les tangentes remises à plat et la largeur à 5.
- Magnétisme mémorisé : grille et alignements proches des autres blocs, avec guides visibles. Désactivé, le dessin et les transformations sont libres au centième de case ; les lignes de départ/arrivée gardent leurs positions et largeurs entières pour rester jouables sur la grille.
- Plume à points d’ancrage et courbes de Bézier : clic pour un angle, clic-glissé pour une courbe, trajet ouvert ou boucle fermée, modification des points et tangentes après création et largeur réglable directement par une poignée. Les tracés libres participent aux collisions, aux sauvegardes et au solveur.
- Aperçu sous le pointeur recalculé après chaque coup, zoom ou déplacement de caméra, même sans déplacer la souris.
- Interface adaptative, préférences de mouvement réduit, contrôles HTML pour toutes les accélérations, libellés accessibles et navigation clavier.

### Contrôles

| Action | Contrôle |
| --- | --- |
| Accélérer | Cliquer une destination ou une case du pavé ; pavé numérique 1–9 |
| Bloc clavier sans pavé | Emplacements QWE / ASD / ZXC en QWERTY, AZE / QSD / WXC en AZERTY |
| Ne pas changer la vitesse | Centre du pavé / touche 5 |
| Annuler le dernier coup | Retour arrière ou bouton ↶ ; active l’entraînement |
| Annuler / rétablir | Ctrl+Z / Ctrl+Maj+Z (Cmd sur Mac), en course et dans l’atelier ; les champs gardent leur historique de saisie natif |
| Recommencer | R ou bouton ↻ |
| Pause | Échap |
| Déplacer la vue de course | Glisser sur la piste |
| Zoom | Molette ou boutons + / − |
| Voir le circuit entier | Bouton ⌖ |
| Placer un bloc dans l’atelier | Clic ou toucher la grille |
| Tourner un bloc | R ou clic droit |
| Déplacer la vue dans l’atelier | Outil Déplacer la vue (souris et tactile), ou bouton du milieu |
| Sélectionner / modifier | Outil Sélectionner (V), puis clic ou glissement d’un bloc |
| Redimensionner un bloc | Tirer un bord, un coin ou une poignée ; pour un virage, bords intérieur et extérieur indépendants |
| Sélectionner un bloc superposé | Alt + clic parcourt les blocs sous le pointeur |
| Dessiner à la plume | P ; clic pour un point anguleux, clic-glissé pour définir ses tangentes |
| Terminer un tracé libre | Entrée ou Terminer le tracé ; cliquer le premier point pour fermer une boucle |
| Éditer une courbe | Déplacer ses points et tangentes ; Alt + glisser un point crée ses tangentes, Alt + glisser une tangente la rend indépendante |
| Supprimer un bloc sélectionné | Suppr ou Supprimer dans le panneau |
| Réinitialiser le bloc sélectionné | Réinitialiser dans le panneau ; une seule étape d’annulation |
| Activer le magnétisme | Toggle Magnétisme ou touche M |
| Annuler un geste en cours | Échap ou annulation du pointeur ; restaure le bloc avant le glissement |

L’éditeur est utilisable au toucher pour la pose, la rotation, le zoom et le déplacement de vue. Le bouton ⌖ cadre tous les blocs posés.

Pour un virage, choisir les deux largeurs (en points de grille) et les rayons intérieurs X/Y. Le début A est situé à l’angle du bloc, la fin B à cet angle +90°. Pour les angles 0° et 180°, la largeur A agit sur le rayon extérieur X et B sur Y ; pour 90° et 270°, les axes s’inversent. Le rayon extérieur vaut `rayon intérieur + largeur − 1`, avec une limite de 60 par axe. L’aperçu indique A/B et leurs largeurs.

L’atelier démarre avec l’outil Sélectionner. Après la pose d’un bloc, il est sélectionné immédiatement pour pouvoir tirer ses bords. Avec le magnétisme actif, les modifications s’alignent sur la grille et sur les repères proches ; les tangentes de la plume s’ajustent par quarts de case. Le mode libre permet des coordonnées et dimensions décimales, réimportables en `.trk`. Les limites géométriques restent contrôlées pendant l’édition ; une entrée invalide ne remplace pas le dernier bloc valide.

Un tracé à la plume dessine l’axe central de la route, avec une largeur de 1 à 40 points de grille. Les points, tangentes et la largeur restent modifiables après validation. Ajouter ensuite un départ et une arrivée, puis Tester mon circuit. Les anciens blocs `.trk` restent pris en charge ; le nouveau type `BezierRoadBlock` requiert cette version du jeu (le prototype Python historique ne le lit pas).

Pendant une démonstration, Espace suspend/reprend la lecture, R la relance et Échap revient à la course. Avec la préférence système de mouvement réduit, la solution démarre en pause ; le bouton Lire lance l’animation.

## Analyse du projet fourni

L’intégralité des 22 fichiers Python (822 lignes), du README et du fichier `full_track.trk` a été examinée avant implémentation. Le projet utilisait Tkinter et NumPy :

| Partie d’origine | Intention et constat |
| --- | --- |
| `Player` | Inertie discrète, neuf choix, historique. Vérification limitée au point final ; arrivée gagnante même à vitesse non nulle ; tableaux par défaut partagés. |
| `Track` et les trois blocs | Union de routes droites, quarts d’ellipse et lignes de départ/arrivée, sérialisation `.trk`. Base géométrique conservée. |
| `Camera` | Vue centrée sur la position projetée avec adaptation au vecteur ; principe repris par la visibilité du prochain coup, le zoom et le déplacement de vue. |
| `Game` | Affichage fonctionnel minimal. Fin de partie : fermeture de l’application, sans écran de résultat, score ni reprise. |
| `MapEditor` et les widgets | Pose de blocs, dimensions, rotation, sauvegarde. Appel à `get_allowed_positions()` inexistant, rafraîchissement après pose manquant et sélection initiale absente. |
| `full_track.trk` | Tracé complexe de 19 blocs. Contient les littéraux Python `True/False`, incompatibles avec le lecteur JSON d’origine. Import sûr ajouté sans `eval`. |

La version principale est désormais le jeu navigateur dans `dist/`. Le lanceur Python conserve l’usage local et les options `-e` et `-t` du projet initial. Le prototype Tkinter est conservé dans `legacy/` comme référence historique, avec correction de ses erreurs bloquantes et des règles de victoire/collision ; son interface historique n’est pas le jeu principal.

## Organisation

```text
dist/engine.js        Règles et géométrie indépendantes de l’interface
dist/renderer.js      Rendu Canvas et transformations de caméra
dist/editor-geometry.js Poignées et transformations des blocs et points
dist/path-geometry.js Géométrie partagée des routes à la plume
dist/i18n.js          Traduction, interpolation et mise à jour des libellés
dist/locales.js       Catalogue de tous les textes en français et en anglais
dist/palette.js       Palette claire partagée par le canvas et les illustrations
dist/app.js           Parcours de jeu, interface et atelier
dist/storage.js       Sauvegardes, validation des reprises et records
dist/tracks.js        Cinq nouveaux circuits
dist/original.trk     Circuit fourni, normalisé en JSON
dist/solver-worker.js Recherche de trajectoires hors du fil d’interface
tests/               Règles, circuits et sauvegardes
legacy/              Sources Tkinter et circuit original
vector-race.py       Lanceur HTTP local sans dépendance
```

### Collisions et solveur

Le moteur conserve le décalage de bord de `1/3` de case et les rayons intérieurs/extérieurs elliptiques. Les rectangles ont un léger débord de `1/3` à leurs extrémités pour uniformiser leurs raccords. Les points jouables du tracé original sont inchangés.

Les collisions découpent chaque segment à toutes ses intersections avec les frontières rectangulaires et elliptiques. Chaque intervalle est classé dans l’union des blocs. Cette méthode ne se contente ni du point final ni d’un échantillonnage approximatif ; elle détecte aussi une sortie de piste entre deux points entiers.

Pour la plume, les cubiques sont aplaties de manière adaptative avec une tolérance de 0,02 case et au plus 4096 points. La route est l’union des capsules de cette polyligne : le rendu et les collisions utilisent exactement cette même géométrie. La validation de déplacement découpe les segments aux intersections avec les côtés et les extrémités circulaires des capsules ; elle ne se contente pas de tester les destinations.

Le solveur explore en largeur les états `(x, y, vx, vy)`. Chaque transition coûte un tour : la première arrivée à l’arrêt donne le minimum. Une limite de 400 000 états et un délai de 20 secondes protègent les circuits personnalisés. Une limite atteinte est signalée, sans être présentée comme une preuve d’impossibilité.

### Langues et apparence

`dist/locales.js` est la source des traductions FR/EN. Chaque clé possède les deux versions ; les paramètres `{p0}`, `{p1}`, etc. doivent rester identiques entre langues. `tr()` gère l’interpolation. Les attributs `data-i18n-slots` traduisent les nœuds de texte HTML en conservant les champs, les contrôles et leurs événements ; les attributs `data-i18n-title` et `data-i18n-aria-label` couvrent aussi les infobulles et l’accessibilité. Le HTML contient un texte français de secours avant l’exécution des modules.

Les préférences `settings.language` et `settings.theme` utilisent la sauvegarde existante, avec français/sombre par défaut pour les anciennes données. Le Worker reçoit la langue de la requête pour ses messages d’erreur. Les textes personnels saisis dans l’éditeur restent inchangés. Les thèmes utilisent des variables CSS ; la palette du canvas et des illustrations est définie dans `dist/palette.js`.

### Vérification

Node.js 20 ou plus récent pour les tests (aucune installation npm nécessaire) :

```bash
node --test tests/*.test.js
```

Les tests couvrent l’inertie, le freinage sur l’arrivée, les collisions continues et les courbes, les raccords, les imports anciens ou invalides, les six courses complètes, les minimums, les limites du solveur et les sauvegardes corrompues. Les tests d’interaction à DOM simulé couvrent aussi les virages asymétriques dans les quatre orientations, la souris immobile après un coup diagonal et un zoom, ainsi que la lecture des six solutions, leur pause, leur annulation et la préservation des courses/records. Des tests supplémentaires couvrent la sélection et les blocs superposés, le déplacement et le redimensionnement, les champs liés, l’annulation d’un geste, la création et l’édition d’une plume, les boucles, les imports et un circuit courbe jouable. Ils ne remplacent pas un contrôle visuel dans un navigateur réel.

La suite vérifie aussi Ctrl+Z / Ctrl+Maj+Z (y compris les points d’une plume en cours), les resets annulables, le magnétisme et sa préférence persistante, les géométries décimales, le choix du départ sans bouton et les circuits personnels en Course : lancement, records, mise à jour, suppression et reprise après rechargement. Les tests FR/EN contrôlent la parité des catalogues et paramètres, la traduction des fenêtres/erreurs/solveur, le changement de langue en pleine course et la préservation des noms personnels. Les préférences sont testées après rechargement et les couleurs principales du thème clair sont vérifiées par calcul du contraste.

## Licence

GNU GPL v3, conformément au projet d’origine. Voir `LICENSE`. Aucun asset tiers, piste musicale, police distante ou dépendance de production ajouté.
